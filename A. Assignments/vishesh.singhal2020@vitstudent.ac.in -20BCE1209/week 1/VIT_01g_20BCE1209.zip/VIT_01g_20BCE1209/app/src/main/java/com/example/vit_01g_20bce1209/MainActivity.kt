package com.example.vit_01g_20bce1209

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import androidx.compose.foundation.clickable
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import java.security.AccessController.getContext
import com.example.vit_01g_20bce1209.ui.theme.VIT_01g_20BCE1209Theme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VIT_01g_20BCE1209Theme {
              app()
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun app(){
    Column(modifier= Modifier
        .fillMaxSize()
        .background(Color.White)
        .padding(all = 16.dp), verticalArrangement = Arrangement.SpaceAround){
//        variable declarations
        var name= remember{ mutableStateOf(TextFieldValue()) };
        var lname= remember{ mutableStateOf(TextFieldValue()) };
        var email= remember{ mutableStateOf(TextFieldValue()) };
        var password= remember{ mutableStateOf(TextFieldValue()) };
        var confirm= remember{ mutableStateOf(TextFieldValue()) };


//
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment
            .CenterVertically, horizontalArrangement = Arrangement.Start){
            Image(painter = painterResource(id = R.drawable.img )  , contentDescription ="" +
                    "" , modifier = Modifier.padding(all=16.dp))
        }
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment
            .CenterVertically, horizontalArrangement = Arrangement.SpaceAround,){

            TextField(placeholder = {Text("first Name")},value =name.value , onValueChange ={name
                .value=it}, modifier = Modifier
                .padding(all = 8.dp)
                .fillMaxWidth(0.46f))
            TextField(placeholder = {Text("last Name ")},value =lname.value , onValueChange ={lname
                .value=it}, modifier = Modifier
                .padding(all = 8.dp)
                .fillMaxWidth(0.9f))
        }
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment
            .CenterVertically, horizontalArrangement = Arrangement.SpaceAround){
            TextField(placeholder = {Text("Email")},value =email.value , onValueChange ={email
                .value=it}, modifier = Modifier
                .padding(all = 8.dp)
                .fillMaxWidth())
        }
        Text(text = "you can use letters,numbers & periods", fontSize = 12.sp, modifier =
        Modifier.padding(horizontal = 18.dp));
        Button(onClick = { /*TODO*/ }, colors= ButtonDefaults.buttonColors(Color.White)) {

            Text(text = "Create a new email address instead",color= Color.Blue, fontSize = 16.sp)
        }

        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment
            .CenterVertically, horizontalArrangement = Arrangement.SpaceAround,){

            TextField(placeholder = {Text("Password")},value =password.value , onValueChange
            ={password
                .value=it},
                modifier =
                Modifier
                    .padding(all = 8.dp)
                    .fillMaxWidth(0.46f))
            TextField(placeholder = {Text("Confirm password", fontSize = 12.sp)},value =confirm
                .value ,
                onValueChange
                ={confirm.value=it}, modifier = Modifier
                    .padding(all = 8.dp)
                    .fillMaxWidth(0.9f))
        }
        Text(text = "Use 8 or more characters .letters,captial letters or numbers speical characters", fontSize = 12.sp, modifier =
        Modifier.padding(horizontal = 18.dp))

        val isChecked = remember { mutableStateOf(false) }
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = isChecked.value,
                onCheckedChange = { isChecked.value = it }
            )

            Text(text="Remember password", fontSize = 16.sp, modifier = Modifier.clickable {
                isChecked.value=!isChecked.value })


        }
        Row(horizontalArrangement = Arrangement.SpaceAround, modifier = Modifier.fillMaxWidth()){
            Button(onClick = { /*TODO*/ }, colors=ButtonDefaults.buttonColors(Color.White)) {

                Text(text = "sign in instead",color= Color.Blue, fontSize = 16.sp)
            }
            Button(onClick = { /*TODO*/ }, colors=ButtonDefaults.buttonColors(Color.Blue)) {

                Text(text = "Next",color= Color.White, fontSize = 16.sp)
            }
        }

    }
}


