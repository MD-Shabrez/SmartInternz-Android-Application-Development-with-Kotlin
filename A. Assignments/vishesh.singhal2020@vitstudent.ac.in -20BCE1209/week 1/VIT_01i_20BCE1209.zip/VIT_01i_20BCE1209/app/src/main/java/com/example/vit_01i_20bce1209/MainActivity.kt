package com.example.vit_01i_20bce1209


import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vit_01i_20bce1209.ui.theme.VIT_01i_20BCE1209Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VIT_01i_20BCE1209Theme {
                // A surface container using the 'background' color from the theme

            MainPage()
            }
        }
    }
}



@Composable
fun EmptyBoxWithBorders() {
    Box(
        modifier = Modifier
            .width(130.dp)
            .height(1.dp)
            .background(color = Color.Transparent)
            .border(
                border = BorderStroke(
                    width = 2.dp,
                    color = Color.Gray
                ),
                shape = RectangleShape
            )
    )
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun textFieldEntry(secondaryColor:Color,placeholder:String,onValueChanged: (String) -> Unit):String{
    val textState = remember { mutableStateOf(TextFieldValue()) }

    OutlinedTextField(
        value = textState.value,
        onValueChange = {values->
            textState.value = values
            onValueChanged(values.text)
        },
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(placeholder,color=secondaryColor) },
        singleLine = true,
        colors = TextFieldDefaults.textFieldColors(containerColor = Color.Transparent, textColor =
        secondaryColor
        )
    )

    return textState.value.text
}


@Composable
fun BlueButton(textstr:String){
    Button(onClick = {

    }, modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),shape = RoundedCornerShape(10.dp),colors= ButtonDefaults.buttonColors
        (containerColor = Color
        .Blue)) {
        Image(painter = painterResource(id = R.drawable.img_1), contentDescription = "facebook " +
                "icon", modifier = Modifier.size(30.dp))
        Text(textstr,color=Color.White, fontSize = 20.sp)
    }
}
@Preview(showBackground = true)
@Composable
fun MainPage(){
    var email by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var userName by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    var primaryColor by remember {
        mutableStateOf(Color.White)
    }
    var secondaryColor by remember {
        mutableStateOf(Color.Black)
    }
    Column(modifier= Modifier
        .verticalScroll(rememberScrollState())
        .padding(all = 16.dp)
        .fillMaxSize()
        .background(primaryColor), verticalArrangement = Arrangement.SpaceAround,
        horizontalAlignment =
        Alignment.CenterHorizontally
    ){
        var expanded by remember { mutableStateOf(false)        }
        Row(horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.Top){

            IconButton(onClick = {expanded=!expanded},) {


                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options", modifier = Modifier.background(Color.White)
                )


            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded=false }, modifier =
            Modifier.background(primaryColor)) {
                DropdownMenuItem(onClick = {
                    primaryColor = Color.Black
                    secondaryColor=Color.White
                }, text = { Text("Dark theme",color=secondaryColor) })


                DropdownMenuItem(onClick = {
                    primaryColor = Color.White
                    secondaryColor=Color.Black
                },text= {
                    Text("Light theme",color=secondaryColor)
                })
            }
        }
        Image(painter = painterResource(id = R.drawable.img), contentDescription =" main " +
                "logo",
            Modifier
                .width(250.dp)
                .height(100.dp))
        Text("Sign up to see photos and videos from your friends.", textAlign = TextAlign.Center,
            fontSize = 20.sp, modifier = Modifier.padding(16.dp), color = secondaryColor, fontWeight
            = FontWeight.Medium)

        BlueButton(textstr = " Login with Facebook")
        Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment
            .CenterVertically){

            EmptyBoxWithBorders();
            Text("OR",modifier= Modifier
                .fillMaxWidth(0.25f)
                .padding(all = 6.dp), textAlign = TextAlign.Center, fontSize = 18.sp,color=secondaryColor)
            EmptyBoxWithBorders();
        }

        Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment
            .CenterHorizontally){

            textFieldEntry(secondaryColor,"Mobile No or Email"){newValue->
                email=newValue
            }
            Spacer(modifier = Modifier.height(10.dp))
            textFieldEntry(secondaryColor,"Full Name"){
                fullName=it
            }
            Spacer(modifier = Modifier.height(10.dp))
            textFieldEntry(secondaryColor,"UserName"){
                userName=it
            }
            Spacer(modifier = Modifier.height(16.dp))
            textFieldEntry(secondaryColor,"Password"){
                password=it
            }
        }
        Row{

            Text("People who use our service may have uploaded your contact information to Instagram" +
                    ".Learn More",textAlign= TextAlign.Center, fontSize = 14.sp,color=secondaryColor)
//        Text("Click here",color=Color.Blue, fontSize =14.sp)
        }
        val context = LocalContext.current

        // below line is use to set our state
        // of dialog box to open as true.
        val openDialog = remember { mutableStateOf(false) }

        // below line is to check if the
        // dialog box is open or not.
        if (openDialog.value) {
            // below line is use to
            // display a alert dialog.
            AlertDialog(
                // on dialog dismiss we are setting
                // our dialog value to false.
                onDismissRequest = { openDialog.value = false },

                // below line is use to display title of our dialog
                // box and we are setting text color to white.
                title = { Text(text = userName, color = Color.White) },

                // below line is use to display
                // description to our alert dialog.
                text = { Text("Hello! $fullName.your email is $email", color = Color.Black) },

                // in below line we are displaying
                // our confirm button.
                confirmButton = {
                    // below line we are adding on click
                    // listener for our confirm button.
                    TextButton(
                        onClick = {
                            openDialog.value = false
                            Toast.makeText(context, "Signed Up", Toast.LENGTH_LONG).show()
                        }
                        , colors = ButtonDefaults.buttonColors(containerColor = Color.Magenta)) {
                        // in this line we are adding
                        // text for our confirm button.
                        Text("Ok", color = Color.White)
                    }
                },
                // in below line we are displaying
                // our dismiss button.

                // below line is use to add background color to our alert dialog
                containerColor = Color.White,

                // below line is use to add content color for our alert dialog.
                textContentColor = Color.Black,
                titleContentColor = Color.Black,
            )
        }

        Row{

            Text("By signing up, you agree to our Terms , Privacy Policy and Cookies Policy .",
                textAlign= TextAlign.Center,color=secondaryColor,fontSize=14.dp)
        }
        Button(onClick = {

            openDialog.value=!openDialog.value

        },shape = RoundedCornerShape(10.dp), colors = ButtonDefaults
            .buttonColors(containerColor =
            Color.Blue), modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()) {
            Text("Sign Up", textAlign = TextAlign.Center,color= Color.White, fontSize = 20.sp)

        }
    }
}