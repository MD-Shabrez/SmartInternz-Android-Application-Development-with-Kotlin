import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.youtubeplayer.YoutubeScreen

@Composable
fun DetailScreen(navController: NavController, videoId:String?, videoT:String?, videoD:String?) {

    var title by remember{
        mutableStateOf("")
    }
    var desc by remember{
        mutableStateOf("")
    }
    if(videoT!=null){
        title=videoT.toString()
    }
    if(videoT!=null){
        if (videoD != null) {
            desc=videoD.toString()
        }
    }
    if (videoId != null) {
        Column() {
            YoutubeScreen(videoId = videoId, modifier = Modifier.fillMaxWidth().height(300.dp) )
            Text(title, fontSize=32.sp, modifier = Modifier.padding(16.dp))
            Text(desc, fontSize = 20.sp, modifier = Modifier.padding(16.dp).background(color =
            Color.LightGray))

        }
    }
}