package com.example.youtubeplayer



import Navigation
import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.R
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.youtubeplayer.ui.theme.YoutubePlayerTheme
import com.google.api.client.googleapis.json.GoogleJsonResponseException
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.youtube.YouTube
import com.google.api.services.youtube.model.SearchListResponse
import kotlinx.coroutines.withContext

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            YoutubePlayerTheme {
                // A surface container using the 'background' color from the theme
            Navigation()
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")

@Composable
fun TopBarsBuilt(){
    Column(modifier = Modifier
        .fillMaxWidth().height(80.dp).background(color = Color.Magenta)){
        Text(text = "VisheshSinghal Fake YT",color= Color.White, fontSize = 32.sp, modifier =
        Modifier.padding(16.dp))
    }
}
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(navController: NavController) {
    Scaffold(topBar = {TopBarsBuilt()}, content = {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            VideoList(navController)
        }

    }) ;

}


data class VideoItem(val title: String, val description: String, val thumbnailUrl: String,val
videoId: String);

@Composable
fun VideoItem(navController: NavController,video: VideoItem) {


        Card(elevation = CardDefaults.cardElevation(defaultElevation = 10.dp), modifier =
        Modifier
            .padding(10.dp)
            .clickable {
                navController.navigate(
                    Screen.detailScreen.withArgs(video.videoId,video.title,video.description)
                )
            }){
            Row(Modifier.fillMaxWidth()){


            Image(
                painter = rememberAsyncImagePainter(video.thumbnailUrl),
                contentDescription = "",
                modifier = Modifier.width(100.dp).height(100.dp),
                contentScale = ContentScale.Crop
            )
            Column(Modifier.padding(16.dp)) {
                Text(text = video.title)
//                Text(text = video.description)
            }
            }
        }

}

@Composable
fun VideoList(navController: NavController) {
    var videos by remember { mutableStateOf(emptyList<VideoItem>()) }

    LaunchedEffect(Unit) {
        fetchVideos { fetchedVideos ->
            videos = fetchedVideos
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())) {
        LazyColumn (modifier=Modifier.size(800.dp)){
            items(videos) { video ->
                VideoItem(navController, video)
            }
        }
    }
}

private suspend fun fetchVideos(onVideosFetched: (List<VideoItem>) -> Unit) {
    withContext(Dispatchers.IO) {
        try {
            val youtube = YouTube.Builder(
                NetHttpTransport(),
                GsonFactory.getDefaultInstance(),
                null
            ).setApplicationName("Your Application Name").build()

            val searchListResponse: SearchListResponse = youtube.search().list("snippet").apply {
                key = "AIzaSyCEJ3EJ09YWAYDkxt2OGFnwagvj1HHaDk0"
                type = "video"
                maxResults = 30 // Number of videos to fetch
                channelId = "UC8butISFwT-Wl7EV0hUK0BQ"
            }.execute()

            val videos = searchListResponse.items.map { video ->
                val title = video.snippet.title
                val description = video.snippet.description
                val thumbnailUrl = video.snippet.thumbnails.default.url
                val videoId = video.id.videoId
//                val videoUrl = "https://www.youtube.com/watch?v=$videoId"
                VideoItem(title, description, thumbnailUrl,videoId)
            }

            // Invoke the callback with the fetched videos
            onVideosFetched(videos)
        } catch (e: GoogleJsonResponseException) {
            // Handle API request errors
            e.printStackTrace()
            onVideosFetched(emptyList())
        }
    }
}
            // Invoke the}


