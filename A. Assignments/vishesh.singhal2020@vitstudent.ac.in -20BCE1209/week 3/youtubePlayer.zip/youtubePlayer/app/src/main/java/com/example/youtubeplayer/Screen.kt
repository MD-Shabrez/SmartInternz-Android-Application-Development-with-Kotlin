package com.example.youtubeplayer

sealed class Screen(val route:String){

    object mainScreen : Screen("main_Screen")
    object detailScreen : Screen("detail_Screen")
    fun withArgs(vararg args:String):String{
        return buildString {
            append(route)
            args.forEach{
                    arg->
                append("/$arg")
            }
        }
    }

}
