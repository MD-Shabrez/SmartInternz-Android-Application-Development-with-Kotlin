
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.youtubeplayer.MainScreen

import com.example.youtubeplayer.Screen
import com.example.youtubeplayer.YoutubeScreen


@Composable
fun Navigation() {
    val navController= rememberNavController()
    NavHost(navController = navController, startDestination = Screen.mainScreen.route ){
        composable(route=Screen.mainScreen.route){
            MainScreen(navController = navController)
        }
        composable(route=Screen.detailScreen
            .route+"/{videoId}/{videoTitle}/{videoDesc}",
            arguments = listOf(
                navArgument("videoId"){
                    type= NavType.StringType
                    defaultValue=" "
                },   navArgument("videoTitle"){
                    type= NavType.StringType
                    defaultValue=" "
                },   navArgument("videoDesc"){
                    type= NavType.StringType
                    defaultValue=" "
                },
            )
        ){entry->
            DetailScreen(navController,
                videoId=   entry.arguments?.getString("videoId"),
                videoT=   entry.arguments?.getString("videoTitle"),
                videoD=   entry.arguments?.getString("videoDesc"),
            )
        }
    }
    
}
