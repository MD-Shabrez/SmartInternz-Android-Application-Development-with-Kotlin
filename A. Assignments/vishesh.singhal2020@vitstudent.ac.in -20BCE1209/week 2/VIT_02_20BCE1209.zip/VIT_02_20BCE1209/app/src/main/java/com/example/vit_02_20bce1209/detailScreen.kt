import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItemDefaults.Elevation
import androidx.compose.material3.NavigationBarDefaults.Elevation
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.w2hw2.topBarUser

@Composable
fun SimpleCard(str:String){
    val paddingModifier  = Modifier.padding(10.dp)
    Card(elevation = CardDefaults.cardElevation(defaultElevation = 10.dp), modifier =
    paddingModifier) {
        Text(text = str,
            modifier = paddingModifier)
    }
}

@SuppressLint("SuspiciousIndentation")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun scaffoldIndetails(
    navController: NavController,
    name: String?,
    lname: String?,
    location: String?,
    age: String?,
    bloodType: String?,
    email: String?,
) {
    var names="User "
        if(name!=null && lname!=null){
            names="$name  $lname"
        }

    Scaffold(topBar ={topBarUser(names)},content={
        DetailScreen(it,navController,name,lname,location,age,bloodType,email)})
}
@Composable
fun DetailScreen(
    useless:PaddingValues,
    navController: NavController,
    name: String?,
    lname: String?,
    location: String?,
    age: String?,
    bloodType: String?,
    email: String?,


) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.DarkGray)
    ) {
        if (name != null && lname != null) {
           SimpleCard(str = "hello $name $lname")

        }
        if (location != null) {
           SimpleCard(str = "location: $location")

        }
        if (age != null) {

            SimpleCard(str = "dob: $age")
        }
        if (bloodType != null) {
            SimpleCard(str ="blood type: $bloodType")

        }
        if (email != null) {
            SimpleCard(str ="email: $email")
        }


    }
}