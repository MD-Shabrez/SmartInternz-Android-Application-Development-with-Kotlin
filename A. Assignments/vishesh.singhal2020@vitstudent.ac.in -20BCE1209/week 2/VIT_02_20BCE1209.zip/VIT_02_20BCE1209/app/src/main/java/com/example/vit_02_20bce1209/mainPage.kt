import android.app.DatePickerDialog
import android.widget.DatePicker
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.w2hw2.Screen
import com.example.w2hw2.textFieldEntry
import java.util.Calendar

@Composable
fun MainScreen(navController: NavController) {
    Column(verticalArrangement = Arrangement.SpaceAround, horizontalAlignment = Alignment
        .CenterHorizontally, modifier = Modifier.padding(25.dp)) {
        rotationLogo(percentage = 1f, number = 100,radius=80.dp )
        var name by remember{
            mutableStateOf("vishesh")
        }
        var location by remember{
            mutableStateOf("india")
        }
        var email by remember{
            mutableStateOf("user123@gmail.com")
        }
        var age by remember{
            mutableStateOf("15")
        }
        var BloodType by remember{
            mutableStateOf("B+")
        }
        var lName by remember{
            mutableStateOf("Singhal")
        }

        val context = LocalContext.current
        val calendar = Calendar.getInstance()

        var selectedDateText by remember { mutableStateOf("01/01/1970") }

// Fetching current year, month and day
        val year = calendar[Calendar.YEAR]
        val month = calendar[Calendar.MONTH]
        val dayOfMonth = calendar[Calendar.DAY_OF_MONTH]


        val datePicker = DatePickerDialog(
            context,
            { _: DatePicker, selectedYear: Int, selectedMonth: Int, selectedDayOfMonth: Int ->
                selectedDateText = "$selectedDayOfMonth/${selectedMonth + 1}/$selectedYear"
            }, year, month, dayOfMonth
        )


        Row(modifier= Modifier
            .fillMaxWidth()
            .padding(all = 10.dp)){

            textFieldEntry(modifier= Modifier
                .weight(1f)
                .padding(16.dp)
                .fillMaxWidth(),placeholder=" first name"){ it->
                name=it
            }
            textFieldEntry(modifier= Modifier
                .weight(1f)
                .padding(16.dp)
                .fillMaxWidth(),placeholder=" Last name"){ it->
                lName=it
            }
        }
        Row(modifier= Modifier
            .fillMaxWidth()
            .padding(all = 10.dp)){

            textFieldEntry(modifier= Modifier
                .weight(1f)
                .padding(16.dp)
                .fillMaxWidth(),
                placeholder="Location"){ it->
                location=it
            }
        }
        Row(modifier= Modifier
            .fillMaxWidth()
            .padding(all = 10.dp)){

            textFieldEntry(modifier= Modifier
                .weight(1f)
                .padding(16.dp)
                .fillMaxWidth(),placeholder="Age"){ it->
                age=it
            }
            textFieldEntry(modifier= Modifier
                .weight(1f)
                .padding(16.dp)
                .fillMaxWidth(),placeholder="Blood Type"){ it->
                BloodType=it
            }
        }
        Row(modifier= Modifier
            .fillMaxWidth()
            .padding(all = 10.dp)){

            textFieldEntry(modifier= Modifier
                .weight(1f)
                .padding(16.dp)
                .fillMaxWidth(),placeholder="email"){ it->
                email=it
            }
        }



        Button(onClick = { navController.navigate(
            Screen.detailScreen.withArgs(name,lName,
            location,age,BloodType,email)) }) {
            Text("Sign Up")
        }

    }
}


